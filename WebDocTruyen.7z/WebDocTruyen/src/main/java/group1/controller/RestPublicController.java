package group1.controller;


import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import group1.model.Account;
import group1.model.Chap;
import group1.model.Images;
import group1.model.TheLoai;
import group1.model.Truyen;
import group1.service.AccountServiceimpl;
import group1.service.ChapServiceimpl;
import group1.service.ImagesServiceIpml;
import group1.service.TheLoaiServiceimpl;
import group1.service.TruyenServiceimpl;
import group1.util.Stringmd5;


@RestController
public class RestPublicController {

	@Autowired
	TheLoaiServiceimpl theLoaiServiceimpl;
	@Autowired
	TruyenServiceimpl truyenServiceimpl;
	@Autowired
	AccountServiceimpl accountServiceimpl;
	@Autowired
	ChapServiceimpl chapServiceimpl;
	@Autowired
	ImagesServiceIpml imagesServiceIpml;
	
	@RequestMapping(value = "/header/", method = RequestMethod.GET)
	public ResponseEntity<List<TheLoai>> listTL(){
		List<TheLoai> listTL = theLoaiServiceimpl.getList();
		 if(listTL.isEmpty()){
	            return new ResponseEntity<List<TheLoai>>(HttpStatus.NO_CONTENT);
	        }
	        return new ResponseEntity<List<TheLoai>>(listTL, HttpStatus.OK);
	}

	@RequestMapping(value = "/listTr_TL/{id}", method = RequestMethod.GET)
	public ResponseEntity<List<Truyen>> listTr_Ca(@PathVariable("id") int id_TL ,HttpSession session){
		List<Truyen> listTr_Ca = truyenServiceimpl.getListTr_TL(id_TL);
		session.setAttribute("listTR_TL", listTr_Ca);
		 if(listTr_Ca.isEmpty()){
	            return new ResponseEntity<List<Truyen>>(HttpStatus.NO_CONTENT);
	        }
	        return new ResponseEntity<List<Truyen>>(listTr_Ca, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/listTr/", method = RequestMethod.GET)
	public ResponseEntity<List<Truyen>> listTr(){
		List<Truyen> listTr = truyenServiceimpl.getListTr(); 
		 if(listTr.isEmpty()){
	            return new ResponseEntity<List<Truyen>>(HttpStatus.NO_CONTENT);
	        }
	        return new ResponseEntity<List<Truyen>>(listTr, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/login/" , method = RequestMethod.POST)
	public ResponseEntity<Integer> login(HttpSession session, @RequestBody Account account){
		Stringmd5 str = new Stringmd5();
		String pass = str.md5(account.getPassWord());
		int id = accountServiceimpl.login(account.getUserName(), pass);
		Account account2 = null;
		if(id != 0){
			account2 = accountServiceimpl.getInforAccount(id);
			session.setAttribute("name", account2.getFullName());
			session.setAttribute("idUser", account2.getId());
			return new ResponseEntity<Integer>(id,HttpStatus.OK);
		}
		return new ResponseEntity<Integer>(id, HttpStatus.NO_CONTENT);
	}
	
	@RequestMapping(value = "/register/" , method = RequestMethod.POST)
	public ResponseEntity<Integer> register(HttpSession session, @RequestBody Account account){
		Stringmd5 str = new Stringmd5();
		String pass = str.md5(account.getPassWord());
		account.setPassWord(pass);
		int check = accountServiceimpl.check(account);
		if(check == 1) {
			return new ResponseEntity<Integer>(0,HttpStatus.NO_CONTENT);
		}	
		session.setAttribute("messageDK", "Đăng ký thành công bạn có thể đăng nhập!");
		accountServiceimpl.register(account);
		return new ResponseEntity<Integer>(1,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/detailChap/{id}" , method = RequestMethod.GET)
	public ResponseEntity<List<Images>> detailChap(HttpSession session, @PathVariable("id") int id ){
		Truyen truyen = truyenServiceimpl.preview(id);
		List<Chap> listChap = chapServiceimpl.getListChap(id);
		int number = chapServiceimpl.lastChap(id);
		Chap chap = chapServiceimpl.getChap(number);
		List<Images> listImg = imagesServiceIpml.getList(number);
		session.setAttribute("chap", chap);
		session.setAttribute("truyen", truyen);
		session.setAttribute("listChap", listChap);
		session.setAttribute("listImg", listImg);
		if(listImg.isEmpty()) {
			 return new ResponseEntity<List<Images>>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Images>>(listImg, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/search/{search}" , method = RequestMethod.GET)
	public ResponseEntity<List<Truyen>> search(HttpSession session, @PathVariable("search") String search ){
		System.out.println("name serach  "  + search);
		List<Truyen> listTr = new LinkedList<Truyen>();
		if(search == null) {
			listTr = truyenServiceimpl.getListTr();
		}else {
			listTr = truyenServiceimpl.findTr(search);
		}
		session.setAttribute("listSearch", listTr);
		System.out.println("list search  = " +listTr.size());
		if(listTr.isEmpty()) {
			 return new ResponseEntity<List<Truyen>>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Truyen>>(listTr, HttpStatus.OK);
	}
}
