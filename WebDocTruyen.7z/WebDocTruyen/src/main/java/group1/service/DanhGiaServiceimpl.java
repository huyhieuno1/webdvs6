package group1.service;

import group1.model.Rate;

public class DanhGiaServiceimpl implements IDanhGiaService{

	@Override
	public void save(Rate dg) {
		// TODO Auto-generated method stub
		
	}

}
