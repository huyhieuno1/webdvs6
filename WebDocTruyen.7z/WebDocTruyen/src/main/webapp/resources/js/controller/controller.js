'use strict';

											/*Lấy list thể loại*/
angular.module('myApp').controller('ListTLController', ['$scope', 'HeaderService', function($scope, HeaderService) {
	fetchMenu();
	$scope.listTL = [];
	function fetchMenu(){
		HeaderService.fetchListTL(function(response){
			$scope.listTL = response;
			console.log(response);
		});
	}
}]);

												/*Lấy list truyện*/
angular.module('myApp').controller('IndexController', ['$scope', 'IndexService', function($scope, IndexService) {
	fetchListTRS();
	$scope.listTR = [];
	
	function fetchListTRS(){
		IndexService.fetchListTR(function(response){
			$scope.listTR = response;
		});	
	}
}]);

											/*Lấy list truyện theo thể loại*/
angular.module('myApp').controller('ListTR_TLController', ['$scope', 'ListTR_TLService', function($scope, ListTR_TLService) {
	
	var host = window.location.host;
	$scope.listTR=[];
	var url = "http://" + host + "/WebDocTruyen";
	function fetchListTR_TLS(id){
		ListTR_TLService.fetchListTR_TL(id,function(response){
    		$scope.listTR= response;
    		console.log($scope.listTR);
    		window.location.href = url + "/category";	
    	}, function(error){
    		console.log('Error!');
    	});
	}
	 $scope.listTRbyid = function(id){
		 fetchListTR_TLS(id);
	 }
}]);
														/*Login*/
angular.module('myApp').controller('LoginController', ['$scope','$window', 'LoginService', function($scope,$window, LoginService) {
	var host = $window.location.host;
	var url = "http://" + host + "/WebDocTruyen";
	function logins(Account){
		LoginService.login(Account,function(response){
			
    		if(response == 0){
    			$scope.status = "Tài khoản hoặc mật khẩu bị sai!";
    		}
    		else{
    			$window.location.href = url+"/";
    		}
    	}, function(error){
    		console.log('Error!');
    	});
    }
	$scope.submit = (Account) => {
		
		logins($scope.Account);
	}
	
}]);

															/*Register*/
angular.module('myApp').controller('RegisterController', ['$scope','$window', 'RegisterService', function($scope,$window, RegisterService) {
	var host = $window.location.host;
	var url = "http://" + host + "/WebDocTruyen";
	function registers(Account){
		RegisterService.register(Account,function(response){
			if(response == 0){
    			$scope.status = "Đăng ký thất bại User đã bị trùng!";
    		}
    		else{
    			$window.location.href = url+"/login";
    		}
    	}, function(error){
    		console.log('Error!');
    	});
    }
	$scope.submit = (Account) => {
		registers($scope.Account);
	}
	
}]);
														/*Detail-Chap*/
angular.module('myApp').controller('DetailController', ['$scope','$window', 'DetailService', function($scope,$window, DetailService) {
	var host = $window.location.host;
	var url = "http://" + host + "/WebDocTruyen";
	$scope.listImg = [];
	$scope.submit = (id) => {
		details(id);
	}
	function details(id){
		DetailService.detail(id,function(response){
	    		$scope.listImg= response;
	    		console.log($scope.listImg);
	    		$window.location.href = url + "/chap-detail";
	    	}, function(error){
	    		console.log('Error!');
	    	});
		
    }

	
}]);

angular.module('myApp').controller('SearchController', ['$scope','$window', 'SearchService', function($scope,$window, SearchService) {
	var host = $window.location.host;
	var url = "http://" + host + "/WebDocTruyen";
	$scope.listSearch = [];
	$scope.submit = (search) => {
		searchs($scope.search);
	}
	function searchs(search){
		SearchService.search(search,function(response){
	    		$scope.listSearch= response;
	    		$window.location.href = url + "/search";
	    	}, function(error){
	    		console.log('Error!');
	    	});
		
    }

	
}]);

/*angular.module('myApp').controller('DetailChapController', ['$scope','$window', 'DetailChapService', function($scope,$window, DetailChapService) {
	var host = $window.location.host;
	var url = "http://" + host + "/WebDocTruyen";
	$scope.listImg = [];
	$scope.submit = (Chap) => {
		console.log(Chap);
	}
	function details(id){
		DetailService.detail(id,function(response){
	    		$scope.listImg= response;
	    		console.log($scope.listImg);
	    		$window.location.href = url + "/chap-detail";
	    	}, function(error){
	    		console.log('Error!');
	    	});
		
    }

	
}]);*/
